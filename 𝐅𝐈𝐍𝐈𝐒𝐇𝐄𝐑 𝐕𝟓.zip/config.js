require("./database/module")


// GLOBAL SETTING
global.owner = "2348144723858"
global.namabot = "Finisher V5"
global.nomorbot = "234xxx"
global.namaCreator = "rage"
global.linkyt = "https://youtube.com/@rage4721"
global.autoJoin = false
global.antilink = false
global.versisc = '7.0.0'

// DELAY JPM
global.delayjpm = 5500



//APIKEY
global.apikey = 'ptla_HDAA07tpGoCk09LZTMbePt6FPrXLwlde1OCMlUbSu7T'

//CAPIKEY
global.capikey = 'ptlc_3215srTKIRGjGpgVb2jFF5TRaj4ROKd78WSnvdvv73q'

//GLOBAL LOCATION
global.location = '1' 

//GLOBAL IMAGE URL
global.imageurl = 'https://vault.pictures/p/55018afae43d4485aee8c5a146d41cd3' 


//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = '-'
global.isLink = 'https://whatsapp.com/channel/0029VafgKHuDjiOa7y21kq37'
global.packname = "I x R"
global.author = "Rage"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})